DELPHI 4 VCL&RTL RESOURCE STRINGS - MEXICAN SPANISH Aug/18/98
-------------------------------------------------------------
These files are the Mexican Spanish language translation of Delphi 4 VCL & RTL strings.

Installation:
-------------
1) Unpack the *.PAS files in '..\Delphi4\Lib\' folder (WITHOUT folder names)
2) Unpack the *.PAS files in '..\Delphi4\Source\' folder (WITH folder names)
3) Load Delphi, open your Project and select Project|Build All Projects to link
   the Spanish resource files into yor Projects

D I S C L A I M E R !
---------------------
This product is FREEWARE, then you can use it for personal or commercial in any way.
You don't need to put my name, but it's always nice to see an acknowledges for me.
THE CODE IS PROVIDED AS IS WITH NO GUARANTEES OF ANY KIND.
USE THIS AT YOUR OWN RISK - YOU ARE THE ONLY PERSON RESPONSIBLE FOR ANY DAMAGE
THIS CODE MAY CAUSE.

For any comments, suggestions (in English or Spanish), adds or just download the
new product version, contact me at:
Name:    Favio E. Ugalde
Country: Mexico
E-Mail:  fugalde@geocities.com
URL:     http://www.geocities.com/SiliconValley/Grid/2582/
